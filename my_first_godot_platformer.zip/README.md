# My First Godot Platformer

A tiny, beginner-friendly 2D platformer starter made with Godot 4.

## Features
- Keyboard controls: A/Left, D/Right, Space to jump
- On-screen touch buttons for Android testing
- Five collectible coins
- Two patrolling enemies
- Simple platforms and score display

## Run
1. Install Godot 4.x from https://godotengine.org/download/
2. Open Godot Project Manager.
3. Choose Import and select this folder's `project.godot`.
4. Open the project and press F6/F5 (or the Play button).

## Controls
- Move: A/D or Left/Right arrows
- Jump: Space
- Restart after game over: R
- On Android, use the on-screen buttons.

## Open source
This starter is provided under the MIT License. See `LICENSE`.
