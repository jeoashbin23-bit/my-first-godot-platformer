extends CharacterBody2D

signal hit_enemy

const SPEED := 260.0
const JUMP_VELOCITY := -470.0
var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var invulnerable := false

func _ready() -> void:
    var collision := CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = Vector2(34, 44)
    collision.shape = shape
    add_child(collision)

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += gravity * delta

    var direction := Input.get_axis("move_left", "move_right")
    velocity.x = direction * SPEED

    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_VELOCITY

    move_and_slide()

    for i in get_slide_collision_count():
        var collider = get_slide_collision(i).get_collider()
        if collider and collider.is_in_group("enemy"):
            hit_enemy.emit()

func _draw() -> void:
    draw_rect(Rect2(-17, -22, 34, 44), Color("#38a6e8"))
    draw_circle(Vector2(-6, -7), 3, Color.WHITE)
    draw_circle(Vector2(6, -7), 3, Color.WHITE)
