extends Area2D

signal collected

func _ready() -> void:
    var collision := CollisionShape2D.new()
    var shape := CircleShape2D.new()
    shape.radius = 15
    collision.shape = shape
    add_child(collision)
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.name == "Player":
        collected.emit()
        queue_free()

func _draw() -> void:
    draw_circle(Vector2.ZERO, 13, Color("#ffd447"))
    draw_circle(Vector2.ZERO, 7, Color("#fff1a6"))
