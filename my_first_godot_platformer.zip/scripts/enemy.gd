extends CharacterBody2D

var direction := 1.0
var speed := 85.0
var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")

func _ready() -> void:
    add_to_group("enemy")
    var collision := CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = Vector2(34, 34)
    collision.shape = shape
    add_child(collision)

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += gravity * delta
    velocity.x = direction * speed
    move_and_slide()
    if is_on_wall():
        direction *= -1

func _draw() -> void:
    draw_rect(Rect2(-17, -17, 34, 34), Color("#df5353"))
    draw_circle(Vector2(-6, -4), 3, Color.WHITE)
    draw_circle(Vector2(6, -4), 3, Color.WHITE)
