extends Node2D

const PlayerScript = preload("res://scripts/player.gd")
const CoinScript = preload("res://scripts/coin.gd")
const EnemyScript = preload("res://scripts/enemy.gd")

var player: CharacterBody2D
var score := 0
var score_label: Label
var message_label: Label
var game_over := false

func _ready() -> void:
    _build_level()
    _build_ui()
    _spawn_player()
    _spawn_coins()
    _spawn_enemies()

func _build_level() -> void:
    # Ground and platforms are StaticBody2D nodes with simple rectangle shapes.
    _make_platform(Vector2(480, 520), Vector2(960, 40))
    _make_platform(Vector2(230, 400), Vector2(220, 24))
    _make_platform(Vector2(540, 315), Vector2(220, 24))
    _make_platform(Vector2(820, 225), Vector2(190, 24))

func _make_platform(pos: Vector2, size: Vector2) -> void:
    var body := StaticBody2D.new()
    body.position = pos
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = size
    shape.shape = rect
    body.add_child(shape)
    var visual := Polygon2D.new()
    visual.polygon = PackedVector2Array([
        Vector2(-size.x/2, -size.y/2), Vector2(size.x/2, -size.y/2),
        Vector2(size.x/2, size.y/2), Vector2(-size.x/2, size.y/2)
    ])
    visual.color = Color("#477b45")
    body.add_child(visual)
    add_child(body)

func _spawn_player() -> void:
    player = CharacterBody2D.new()
    player.name = "Player"
    player.position = Vector2(90, 450)
    player.set_script(PlayerScript)
    add_child(player)
    player.hit_enemy.connect(_on_player_hit)

func _spawn_coins() -> void:
    for p in [Vector2(230, 355), Vector2(540, 270), Vector2(820, 180), Vector2(420, 470), Vector2(700, 470)]:
        var coin := Area2D.new()
        coin.position = p
        coin.set_script(CoinScript)
        coin.collected.connect(_on_coin_collected)
        add_child(coin)

func _spawn_enemies() -> void:
    for p in [Vector2(390, 480), Vector2(690, 480)]:
        var enemy := CharacterBody2D.new()
        enemy.position = p
        enemy.set_script(EnemyScript)
        add_child(enemy)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    score_label = Label.new()
    score_label.position = Vector2(20, 15)
    score_label.add_theme_font_size_override("font_size", 26)
    score_label.text = "Coins: 0"
    layer.add_child(score_label)

    message_label = Label.new()
    message_label.position = Vector2(350, 15)
    message_label.add_theme_font_size_override("font_size", 22)
    message_label.text = "Collect coins and avoid enemies!"
    layer.add_child(message_label)

    _add_touch_button(layer, "◀", Vector2(25, 420), "move_left")
    _add_touch_button(layer, "▶", Vector2(115, 420), "move_right")
    _add_touch_button(layer, "JUMP", Vector2(805, 405), "jump")

func _add_touch_button(layer: CanvasLayer, caption: String, pos: Vector2, action: String) -> void:
    var button := Button.new()
    button.text = caption
    button.position = pos
    button.custom_minimum_size = Vector2(78, 78)
    button.add_theme_font_size_override("font_size", 22)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    layer.add_child(button)

func _on_coin_collected() -> void:
    score += 1
    score_label.text = "Coins: %d / 5" % score
    if score == 5:
        message_label.text = "All coins collected! Great job!"

func _on_player_hit() -> void:
    if game_over:
        return
    game_over = true
    message_label.text = "Game over! Press R to restart."

func _process(_delta: float) -> void:
    if game_over and Input.is_key_pressed(KEY_R):
        get_tree().reload_current_scene()
